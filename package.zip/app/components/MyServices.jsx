import React from "react";
import Image from "next/image";
import Link from "next/link";

function MyServices() {
  return (
    <div className="p-8">
      <h1 className="text-6xl font-bold my-10">My Services</h1>
      <div className="flex items-center flex-col md:flex-row justify-between gap-10">
        <div className="bg-white/30 -z-10 h-96 max-w-[350px] rounded-2xl p-6">
          <Image
            src="/front-end-project.webp"
            alt="Service 1"
            className="h-44 rounded-2xl"
            width={500}
            height={500}
          />
          <p className="text-2xl font-bold mt-4">Service 1</p>
          <p className="text-sm my-3">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do
            eiusmod tempor incididunt ut labore et dolore magna aliqua.
          </p>
          <p className="user-select-none text-main-secondary-color font-bold cursor-pointer hover:underline hover:text-main-color">
            Project Link
          </p>
          <Link
            href="/"
            className="text-main-secondary-color font-bold cursor-pointer hover:underline hover:text-main-color"
          >
            Github Link
          </Link>
        </div>
      </div>
    </div>
  );
}

export default MyServices;

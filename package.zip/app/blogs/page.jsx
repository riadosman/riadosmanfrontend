import Link from "next/link";

export default async function Blogs() {
  const res = await fetch("http://localhost:3000/api/blogs", {
    cache: "no-store",
  });
  const data = await res.json();

  return (
    <div className="p-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {data.map((blog) => (
        <div
          key={blog._id}
          className="bg-secondary-primary-color text-white p-4 rounded-lg shadow-md"
        >
          <img
            src={blog.image}
            alt={blog.title}
            className="w-full h-48 object-cover rounded mb-4"
          />
          <h2 className="text-xl font-bold mb-2">{blog.title}</h2>
          <p className="text-gray-300 mb-2">{blog.description}</p>
          <p className="text-gray-400 text-sm mb-2">
            By {blog.author} • {blog.views} views • {blog.likes} likes
          </p>
          <Link
            href={`/blogs/${blog._id}`}
            className="mt-2 bg-red-600 px-3 py-1 rounded hover:bg-red-700"
          >
            See More
          </Link>
        </div>
      ))}
    </div>
  );
}

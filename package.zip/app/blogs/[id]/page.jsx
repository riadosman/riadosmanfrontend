import Image from "next/image";
export default async function BlogDetail({ params }) {
  const { id } = await params;
  const res = await fetch("http://localhost:3000/api/blogs", {
    cache: "no-store",
  });
  const data = await res.json();
  console.log(id);

  const blog = data.find((b) => b._id === id);

  return (
    <div>
      <Image src={blog.image} alt={blog.title} width={500} height={500} />
      <div className="p-8">
        <h1 className="text-3xl my-5 capitalize font-bold">{blog.title}</h1>
        <p>{blog.description}</p>
      </div>
    </div>
  );
}

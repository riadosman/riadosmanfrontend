import About from "./components/About";
import Hero from "./components/Hero";
import MyServices from "./components/MyServices";
export default function Home() {
  return (
    <div className="relative h-screen w-full -z-10">
      <div className="absolute -top-40 -left-40 w-[500px] h-[500px] blur-[200px] bg-main-color"></div>
      <div className="absolute -top-40 right-0 w-[200px] h-[200px] blur-[100px] bg-main-secondary-color"></div>

      <Hero />
      <About />
      <MyServices />
    </div>
  );
}

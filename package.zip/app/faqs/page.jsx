export default function FAQs() {
  return <div>FAQs</div>;
}
